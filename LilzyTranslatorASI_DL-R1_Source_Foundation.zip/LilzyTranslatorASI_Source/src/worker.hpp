#pragma once
#include <string>
#include <functional>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <atomic>

class TranslationWorker {
public:
    using Job = std::function<void()>;
    explicit TranslationWorker(std::size_t maxQueue = 10);
    ~TranslationWorker();
    bool Enqueue(Job job);
    void Stop();
private:
    void Run();
    std::queue<Job> jobs_;
    std::mutex mutex_;
    std::condition_variable cv_;
    std::thread thread_;
    std::atomic<bool> stopping_{false};
    std::size_t maxQueue_;
};
