#include <windows.h>
#include <fstream>
#include <string>
#include "config.hpp"
#include "player_filter.hpp"
#include "worker.hpp"
#include "samp_client.hpp"

static HMODULE g_module = nullptr;
static HANDLE g_thread = nullptr;
static TranslationWorker* g_worker = nullptr;
static LilzyConfig g_config;
static SampClient g_samp;

static void Log(const char* msg) {
    std::ofstream out("lilzy_translator.log", std::ios::app);
    if (out.good()) out << msg << "\r\n";
}
static DWORD WINAPI Initialize(void*) {
    LoadConfig(g_config);
    Log("[Lilzy ASI] Loaded. Waiting for SA-MP client module...");
    // Detection only. No version-specific SA-MP hooks are installed in this starter.
    for (int i = 0; i < 300 && !GetModuleHandleA("samp.dll"); ++i) Sleep(100);
    if (GetModuleHandleA("samp.dll")) {
        std::string reason;
        if (g_samp.Detect(reason)) Log("[Lilzy ASI] SA-MP 0.3.DL-R1 interface validated.");
        else Log((std::string("[Lilzy ASI] Client validation failed: ") + reason).c_str());
    } else {
        Log("[Lilzy ASI] samp.dll not detected within 30 seconds.");
    }
    g_worker = new TranslationWorker(10);
    Log("[Lilzy ASI] DL-R1 detection, CFG, whitelist and bounded worker initialized. Chat command/API/HUD integration pending.");
    return 0;
}
BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_module = hModule;
        DisableThreadLibraryCalls(hModule);
        g_thread = CreateThread(nullptr, 0, Initialize, nullptr, 0, nullptr);
    } else if (reason == DLL_PROCESS_DETACH) {
        if (g_worker) { g_worker->Stop(); delete g_worker; g_worker = nullptr; }
        if (g_thread) { CloseHandle(g_thread); g_thread = nullptr; }
    }
    return TRUE;
}
