#include "worker.hpp"
TranslationWorker::TranslationWorker(std::size_t maxQueue) : maxQueue_(maxQueue), thread_(&TranslationWorker::Run, this) {}
TranslationWorker::~TranslationWorker() { Stop(); }
bool TranslationWorker::Enqueue(Job job) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (stopping_ || jobs_.size() >= maxQueue_) return false;
    jobs_.push(std::move(job)); cv_.notify_one(); return true;
}
void TranslationWorker::Stop() {
    if (stopping_.exchange(true)) return;
    cv_.notify_all();
    if (thread_.joinable()) thread_.join();
}
void TranslationWorker::Run() {
    for (;;) {
        Job job;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            cv_.wait(lock, [&] { return stopping_ || !jobs_.empty(); });
            if (stopping_ && jobs_.empty()) return;
            job = std::move(jobs_.front()); jobs_.pop();
        }
        try { if (job) job(); } catch (...) {}
    }
}
