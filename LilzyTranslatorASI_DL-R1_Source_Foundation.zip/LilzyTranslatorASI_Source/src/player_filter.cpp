#include "player_filter.hpp"
#include <algorithm>
#include <cctype>

static std::string Lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(),
        [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return s;
}
LockResult AddLockedPlayer(LilzyConfig& cfg, const std::string& name) {
    if (name.empty() || name.size() > 24) return LockResult::Invalid;
    for (char c : name) if (!(std::isalnum((unsigned char)c) || c == '_')) return LockResult::Invalid;
    for (const auto& n : cfg.lockedPlayers) if (!n.empty() && Lower(n) == Lower(name)) return LockResult::AlreadyExists;
    for (auto& n : cfg.lockedPlayers) if (n.empty()) { n = name; SaveConfig(cfg); return LockResult::Added; }
    return LockResult::Full;
}
void ClearLockedPlayers(LilzyConfig& cfg) {
    for (auto& n : cfg.lockedPlayers) n.clear();
    SaveConfig(cfg);
}
bool IsPlayerLocked(const LilzyConfig& cfg, const std::string& name) {
    for (const auto& n : cfg.lockedPlayers) if (!n.empty() && Lower(n) == Lower(name)) return true;
    return false;
}
