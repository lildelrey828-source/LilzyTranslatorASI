#include "config.hpp"
#include <windows.h>
#include <fstream>
#include <sstream>
#include <algorithm>

static std::string Trim(std::string s) {
    const auto a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return {};
    const auto b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}
static std::string GetValue(const std::string& line) {
    const auto p = line.find('=');
    return p == std::string::npos ? std::string{} : Trim(line.substr(p + 1));
}
std::string ConfigPath() {
    char path[MAX_PATH]{};
    GetCurrentDirectoryA(MAX_PATH, path);
    return std::string(path) + "\\lilzy_translator.ini";
}
bool LoadConfig(LilzyConfig& cfg) {
    std::ifstream in(ConfigPath());
    if (!in.good()) return SaveConfig(cfg);
    std::string line, section;
    while (std::getline(in, line)) {
        line = Trim(line);
        if (line.empty() || line[0] == ';' || line[0] == '#') continue;
        if (line.front() == '[' && line.back() == ']') {
            section = line.substr(1, line.size() - 2); continue;
        }
        const auto p = line.find('=');
        if (p == std::string::npos) continue;
        const auto key = Trim(line.substr(0, p));
        const auto val = GetValue(line);
        if (section == "general") {
            if (key == "enabled") cfg.enabled = (val == "1" || val == "true");
            else if (key == "provider") cfg.provider = val;
            else if (key == "api_key") cfg.apiKey = val;
        } else if (section == "player_filter") {
            if (key == "name_1") cfg.lockedPlayers[0] = val;
            else if (key == "name_2") cfg.lockedPlayers[1] = val;
            else if (key == "name_3") cfg.lockedPlayers[2] = val;
        } else if (section == "overlay") {
            try {
                if (key == "x") cfg.hudX = std::stof(val);
                else if (key == "y") cfg.hudY = std::stof(val);
            } catch (...) {}
            if (key == "visible") cfg.hudVisible = (val == "1" || val == "true");
        }
    }
    return true;
}
bool SaveConfig(const LilzyConfig& cfg) {
    std::ofstream out(ConfigPath(), std::ios::trunc);
    if (!out.good()) return false;
    out << "[general]\nenabled=" << (cfg.enabled ? 1 : 0)
        << "\nprovider=" << cfg.provider << "\napi_key=" << cfg.apiKey
        << "\n\n[player_filter]\ncount=";
    int count = 0; for (const auto& n : cfg.lockedPlayers) if (!n.empty()) ++count;
    out << count << '\n';
    for (int i = 0; i < 3; ++i) out << "name_" << (i + 1) << '=' << cfg.lockedPlayers[i] << '\n';
    out << "\n[overlay]\nx=" << cfg.hudX << "\ny=" << cfg.hudY
        << "\nvisible=" << (cfg.hudVisible ? 1 : 0) << '\n';
    return out.good();
}
