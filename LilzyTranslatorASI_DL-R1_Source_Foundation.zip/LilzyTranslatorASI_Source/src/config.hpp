#pragma once
#include <string>
#include <array>

struct LilzyConfig {
    bool enabled = true;
    std::string provider = "free";
    std::string apiKey;
    std::array<std::string, 3> lockedPlayers{};
    float hudX = 40.0f;
    float hudY = 180.0f;
    bool hudVisible = true;
};

bool LoadConfig(LilzyConfig& cfg);
bool SaveConfig(const LilzyConfig& cfg);
std::string ConfigPath();
