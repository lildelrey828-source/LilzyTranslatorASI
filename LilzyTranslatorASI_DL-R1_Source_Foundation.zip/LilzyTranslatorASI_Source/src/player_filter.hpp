#pragma once
#include "config.hpp"
#include <string>

enum class LockResult { Added, AlreadyExists, Full, Invalid };
LockResult AddLockedPlayer(LilzyConfig& cfg, const std::string& name);
void ClearLockedPlayers(LilzyConfig& cfg);
bool IsPlayerLocked(const LilzyConfig& cfg, const std::string& name);
