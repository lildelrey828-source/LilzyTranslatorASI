LILZY TRANSLATOR ASI — DL-R1 NATIVE FOUNDATION
=============================================

TARGET CLIENT (IDENTIFIED FROM THE USER'S DLL)
- GTA San Andreas PC 1.0 US (32-bit)
- SA-MP 0.3.DL-R1 (32-bit)
- Windows / ASI Loader
- Visual Studio 2022, Platform: Win32, Configuration: Release

WHAT CHANGED IN THIS REVISION
-----------------------------
- Replaced the old generic samp.dll presence check with a strict 0.3.DL-R1
  signature check at samp.dll + 0xBABE.
- Added a DL-R1-only address map for the chat/input/game interface pointer
  slots and known chat/command functions.
- Added PE32 image validation, readable pointer-slot checks, and executable
  memory checks before the plugin reports the client interface as validated.
- Startup log now clearly reports a mismatch rather than attempting to use
  offsets from a different SA-MP build.
- Existing CFG, max-three exact-name whitelist, and bounded worker queue remain.

CLIENT FILE CHECK
-----------------
The supplied samp.dll is PE32 / Intel 80386, ImageBase 0x10000000,
SizeOfImage 0x2BE000. The 10-byte version probe at RVA 0xBABE matches:
52 8D 44 24 0C 50 8D 7E 09 E8 (SA-MP 0.3.DL-R1).
SHA-256: bccdb297464bd382625635be25585df07a8fa6668bc0015650708e3eb4ffcd4b

The DL-R1 RVAs used here are documented in the SA-MP API reference source:
- chat info pointer: 0x2ACA10
- input info pointer: 0x2ACA14
- SA-MP base pointer: 0x2ACA24
- game info pointer: 0x2ACA3C
- register chat command: 0x0691B0
- add chat message: 0x067650
- send command: 0x069340
- say: 0x005860

IMPORTANT STATUS
----------------
This is still an intermediate native foundation, NOT a finished translator.
The following are not implemented yet:
- Actual /lock and /clearlock registration in the SA-MP chat input.
- Incoming player-chat interception and filtering before translation.
- HTTP requests to Free/Groq and JSON response parsing.
- Main-thread-safe translated chat output.
- Direct3D9/ImGui HUD, drag handling, and saved HUD position.
- Language Styles and Mood port from the Android Lua version.

No game hook is installed by this revision. It validates the exact client
build and interface addresses first, reducing the risk of calling offsets
from the wrong SA-MP version. A matching signature is not a substitute for
runtime testing in GTA/SA-MP.

BUILD
-----
1. Open LilzyTranslatorASI.vcxproj in Visual Studio 2022.
2. Choose Release | Win32.
3. Build > Build Solution.
4. Output: bin\Release\LilzyTranslator.asi

This environment does not have the Windows x86 MSVC/MinGW toolchain or a
running GTA SA client, so no binary has been built or game-tested here.

CFG
---
The plugin creates lilzy_translator.ini in the game's working directory.
Keep API keys private; do not publish the INI file or screenshots containing it.
